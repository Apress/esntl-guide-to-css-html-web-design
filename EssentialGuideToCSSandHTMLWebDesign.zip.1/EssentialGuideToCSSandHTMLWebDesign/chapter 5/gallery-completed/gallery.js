function swapPhoto(photoSRC) 
	{ 
	document.images.imgPhoto.src = "assets/" + photoSRC; 
	} 
